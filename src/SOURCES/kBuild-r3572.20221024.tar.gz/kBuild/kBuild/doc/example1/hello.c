/* $Id: hello.c 2343 2009-04-19 21:44:50Z bird $ */
/** @file
 * Example no. 1 - hello.c - Hello world program.
 */

/*
 * The author disclaims copyright to this example code and places
 * it in the public domain.
 *
 * #include <full-legal-disclaimer.h>
 *
 */

#include <stdio.h>

int main()
{
    printf("Hello world!\n");
    return 0;
}

